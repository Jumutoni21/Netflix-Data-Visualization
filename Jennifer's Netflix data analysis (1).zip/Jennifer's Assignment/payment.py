class Payment:
    def __init__(self, payment_id, policyholder, amount, penalty=0, is_paid=False):
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.amount = amount
        self.penalty = penalty
        self.is_paid = is_paid

    # Getters
    def get_payment_id(self):
        return self.payment_id

    def get_policyholder(self):
        return self.policyholder

    def get_amount(self):
        return self.amount

    def get_penalty(self):
        return self.penalty

    def get_payment_status(self):
        return "Paid" if self.is_paid else "Unpaid"

    # Setters
    def set_amount(self, amount):
        self.amount = amount

    def set_penalty(self, penalty):
        self.penalty = penalty

    # Methods
    def process_payment(self):
        self.is_paid = True
        print(f"Payment of {self.amount} by {self.policyholder.get_name()} processed successfully.")

    def send_reminder(self):
        print(f"Reminder: {self.policyholder.get_name()}, your payment of {self.amount} is due.")

    def apply_penalty(self, penalty):
        self.penalty = penalty
        print(f"A penalty of {penalty} has been applied to {self.policyholder.get_name()}.")
