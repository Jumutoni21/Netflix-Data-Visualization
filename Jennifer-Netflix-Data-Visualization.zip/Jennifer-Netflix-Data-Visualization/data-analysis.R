library(ggplot2)

netflix_data_cleaned <- read.csv("netflix_data_cleaned.csv")

# Create a bar plot for the ratings distribution
ggplot(netflix_data_cleaned, aes(x=rating)) +
    geom_bar(fill="blue", color="black") +
    ggtitle("Ratings Distribution") +
    xlab("Rating") +
    ylab("Frequency")

ggsave("ratings_Distribution.png")